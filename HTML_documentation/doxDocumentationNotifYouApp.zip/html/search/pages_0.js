var searchData=
[
  ['notifyou_20android_20app_20_20documentation',['notifYou Android app  documentation',['../index.html',1,'']]]
];
