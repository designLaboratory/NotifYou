var searchData=
[
  ['updatecntdisplay',['updateCntDisplay',['../classesapp_1_1com_1_1notifyoulight_1_1_main_activity.html#ad9583407024bcd0c893a096074ad7913',1,'esapp::com::notifyoulight::MainActivity']]]
];
