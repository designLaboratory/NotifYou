var searchData=
[
  ['notifyou_20android_20app_20_20documentation',['notifYou Android app  documentation',['../index.html',1,'']]],
  ['notifyouconnect',['notifYouConnect',['../classesapp_1_1com_1_1notifyoulight_1_1_main_activity.html#ab5badc8833a8087d78eb79a61cb06e0a',1,'esapp::com::notifyoulight::MainActivity']]]
];
