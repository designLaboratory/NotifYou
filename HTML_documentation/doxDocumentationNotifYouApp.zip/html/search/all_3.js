var searchData=
[
  ['oncreate',['onCreate',['../classesapp_1_1com_1_1notifyoulight_1_1_main_activity.html#af9c7efe7c1a5f9a6593bfb3e5a3a3758',1,'esapp::com::notifyoulight::MainActivity']]]
];
