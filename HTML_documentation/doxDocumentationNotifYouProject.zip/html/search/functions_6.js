var searchData=
[
  ['scroll_5fsyms',['scroll_syms',['../_r_g_b_w___l_e_ds__driver_8c.html#ad0741f5fcf73c8dbab2b65dcdfdb2d60',1,'scroll_syms(void):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#ad0741f5fcf73c8dbab2b65dcdfdb2d60',1,'scroll_syms(void):&#160;RGBW_LEDs_driver.c']]],
  ['set_5fmatrix_5foff',['set_matrix_off',['../_r_g_b_w___l_e_ds__driver_8c.html#a8cf4abbef8cf044fb771223bb7957482',1,'set_matrix_off(void):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#a8cf4abbef8cf044fb771223bb7957482',1,'set_matrix_off(void):&#160;RGBW_LEDs_driver.c']]],
  ['single_5ftap_5finit',['Single_Tap_Init',['../accelero_8c.html#ab5b1688fcc128fc262bd7a05f3beccb8',1,'Single_Tap_Init():&#160;accelero.c'],['../accelero_8h.html#a1e0aed656b4c870fa12ed7cd7ab8ad75',1,'Single_Tap_Init(void):&#160;accelero.c']]],
  ['start_5fdma',['start_DMA',['../_r_g_b_w___l_e_ds__driver_8c.html#a2b068556f66a6c1160fdfac95dee3310',1,'start_DMA():&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#ac46b79bbc9704b96eda83e99e492b160',1,'start_DMA(void):&#160;RGBW_LEDs_driver.c']]],
  ['start_5fi2c',['start_I2C',['../i2c_8c.html#a3771197a792a178893ea1ca656f338bc',1,'start_I2C():&#160;i2c.c'],['../i2c_8h.html#a2cddf4acdfee7d7a839b2af9cf837847',1,'start_I2C(void):&#160;i2c.c']]],
  ['stop_5fi2c',['stop_I2C',['../i2c_8c.html#afffa128072914512323232c55e601d95',1,'stop_I2C():&#160;i2c.c'],['../i2c_8h.html#a4c6741313a709bb8e788d6c1cbd29b67',1,'stop_I2C(void):&#160;i2c.c']]]
];
