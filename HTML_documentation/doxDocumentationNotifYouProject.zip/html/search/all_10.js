var searchData=
[
  ['wait_5fi2c',['wait_I2C',['../i2c_8c.html#aed5edfab555d0939a9323c73a76fe42d',1,'wait_I2C():&#160;i2c.c'],['../i2c_8h.html#aa914039cec7eaa4704a71e7bf1e63361',1,'wait_I2C(void):&#160;i2c.c']]],
  ['wait_5fns',['wait_ns',['../i2c_8c.html#a3c33d14a02367a3d5a8df3c0b61ce6e8',1,'wait_ns(uint16_t val_ns):&#160;i2c.c'],['../i2c_8h.html#a3c33d14a02367a3d5a8df3c0b61ce6e8',1,'wait_ns(uint16_t val_ns):&#160;i2c.c']]],
  ['who_5fam_5fi',['WHO_AM_I',['../accelero_8h.html#a9fcb9e460d175bfc7ab4d80bf788b43a',1,'accelero.h']]]
];
