var searchData=
[
  ['nsec_5fto_5fticks',['NSEC_TO_TICKS',['../_r_g_b_w___l_e_ds__driver_8c.html#a2ca12fad54b07ef7cd2e1d7f9aef54f2',1,'RGBW_LEDs_driver.c']]],
  ['num_5fof_5fleds',['NUM_OF_LEDS',['../_r_g_b_w___l_e_ds__driver_8c.html#a42308849576b2f1ead04e472d38985da',1,'RGBW_LEDs_driver.c']]],
  ['num_5fof_5fnotifs',['NUM_OF_NOTIFS',['../_r_g_b_w___l_e_ds__driver_8c.html#a7a60675fef4520a6afc43d6ad332177c',1,'RGBW_LEDs_driver.c']]]
];
