var searchData=
[
  ['off_5fx',['OFF_X',['../accelero_8h.html#ae9ab42a3b6f9cd6e1337cbbc037e7c6e',1,'accelero.h']]],
  ['off_5fy',['OFF_Y',['../accelero_8h.html#a1b5bcb3dbe14a1294e33f8e27cc4561e',1,'accelero.h']]],
  ['off_5fz',['OFF_Z',['../accelero_8h.html#ae1a1979da2f92947322b2b60ee0d5dbc',1,'accelero.h']]],
  ['out_5fpin',['OUT_PIN',['../_r_g_b_w___l_e_ds__driver_8c.html#a4077bef57f7b230360d3c9fd61abe7b7',1,'RGBW_LEDs_driver.c']]],
  ['out_5fx_5flsb',['OUT_X_LSB',['../accelero_8h.html#a6ff2ff1a6177ce1c8e3d633e727c7e8f',1,'accelero.h']]],
  ['out_5fx_5fmsb',['OUT_X_MSB',['../accelero_8h.html#a5b104460d2b3843bfc2792c89c02da04',1,'accelero.h']]],
  ['out_5fy_5flsb',['OUT_Y_LSB',['../accelero_8h.html#af2eaa05fe790ed6388bea81043cb0681',1,'accelero.h']]],
  ['out_5fy_5fmsb',['OUT_Y_MSB',['../accelero_8h.html#aa72e3e30cde75c17c3ffc027cc78651d',1,'accelero.h']]],
  ['out_5fz_5flsb',['OUT_Z_LSB',['../accelero_8h.html#aec8fbd55a6e15141f231889ea3de0152',1,'accelero.h']]],
  ['out_5fz_5fmsb',['OUT_Z_MSB',['../accelero_8h.html#afdee7c733b8cc6331eaea07166abb906',1,'accelero.h']]]
];
