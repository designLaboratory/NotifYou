var searchData=
[
  ['status_5ff_5fstatus',['STATUS_F_STATUS',['../accelero_8h.html#ae8adfad4e8375933f9396b88464c0b9e',1,'accelero.h']]],
  ['sysmod',['SYSMOD',['../accelero_8h.html#a988cc6de0448e652d50b31045c41d4ce',1,'accelero.h']]]
];
