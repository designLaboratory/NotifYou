var searchData=
[
  ['dma_5fdata',['dma_data',['../_r_g_b_w___l_e_ds__driver_8c.html#a6404e7bae21ac6c88eeee2f1a6e4a3d5',1,'RGBW_LEDs_driver.c']]],
  ['dma_5fdone_5fstatus',['dma_done_status',['../_r_g_b_w___l_e_ds__driver_8c.html#af5db00850dec3184a424b0689e63d07b',1,'RGBW_LEDs_driver.c']]],
  ['dma_5fout_5fmask',['DMA_out_mask',['../_r_g_b_w___l_e_ds__driver_8c.html#ad73042fae84f947310f8ab2bba8b04b5',1,'RGBW_LEDs_driver.c']]],
  ['dma_5fwords',['dma_words',['../_r_g_b_w___l_e_ds__driver_8c.html#aae984b2c5d1f57c419c341ced100e515',1,'RGBW_LEDs_driver.c']]]
];
