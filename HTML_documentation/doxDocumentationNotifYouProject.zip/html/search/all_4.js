var searchData=
[
  ['guardtime_5fperiod',['guardtime_period',['../_r_g_b_w___l_e_ds__driver_8c.html#aa52a82e9afc95c7c392478657c245917',1,'RGBW_LEDs_driver.c']]]
];
