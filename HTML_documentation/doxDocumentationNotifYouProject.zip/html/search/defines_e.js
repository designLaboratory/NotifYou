var searchData=
[
  ['who_5fam_5fi',['WHO_AM_I',['../accelero_8h.html#a9fcb9e460d175bfc7ab4d80bf788b43a',1,'accelero.h']]]
];
