var searchData=
[
  ['xyz_5fdata_5fcfg',['XYZ_DATA_CFG',['../accelero_8h.html#a6a9a7c12dbef16dad229b36db5815241',1,'accelero.h']]]
];
