var searchData=
[
  ['return_5fsym',['return_sym',['../_r_g_b_w___l_e_ds__driver_8c.html#ab1ccb3fc5471fcac99d5d70f52ee8f50',1,'return_sym(uint8_t notif_tab[60], uint8_t pos):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#ab1ccb3fc5471fcac99d5d70f52ee8f50',1,'return_sym(uint8_t notif_tab[60], uint8_t pos):&#160;RGBW_LEDs_driver.c']]],
  ['rst_5fi2c',['rst_I2C',['../i2c_8c.html#a4d262f82430ecc3e37367897a2651acc',1,'rst_I2C():&#160;i2c.c'],['../i2c_8h.html#a15d88efb6d87d41732e63bbc6bc55dd4',1,'rst_I2C(void):&#160;i2c.c']]]
];
