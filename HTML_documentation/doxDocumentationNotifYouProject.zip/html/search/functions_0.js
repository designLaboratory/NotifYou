var searchData=
[
  ['accelero_5fset_5factive',['Accelero_Set_Active',['../accelero_8c.html#a368b34e3705d1837e4ba877ed8fe5499',1,'Accelero_Set_Active():&#160;accelero.c'],['../accelero_8h.html#ad4330e73449e604d365c44a6f9b914c8',1,'Accelero_Set_Active(void):&#160;accelero.c']]]
];
