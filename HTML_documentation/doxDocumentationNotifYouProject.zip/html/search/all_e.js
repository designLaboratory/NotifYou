var searchData=
[
  ['tpm0_5firqhandler',['TPM0_IRQHandler',['../_r_g_b_w___l_e_ds__driver_8c.html#a1bdae61dd9f5e17df8eaf6356044ea92',1,'TPM0_IRQHandler():&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#a346f8023e360ddffd61e34867b30d157',1,'TPM0_IRQHandler(void):&#160;RGBW_LEDs_driver.c']]],
  ['tpm_5fp0_5fperiod',['tpm_p0_period',['../_r_g_b_w___l_e_ds__driver_8c.html#a6cdd70e5d174a5ca9925bfef099cafdb',1,'RGBW_LEDs_driver.c']]],
  ['tpm_5fp1_5fperiod',['tpm_p1_period',['../_r_g_b_w___l_e_ds__driver_8c.html#ab01471d6ed5e172370af0146f2b6df2b',1,'RGBW_LEDs_driver.c']]],
  ['tpm_5fperiod',['tpm_period',['../_r_g_b_w___l_e_ds__driver_8c.html#a4aedc62a6dffa54d596430c03fcbf056',1,'RGBW_LEDs_driver.c']]],
  ['trailing_5fzeros_5f1',['trailing_zeros_1',['../_r_g_b_w___l_e_ds__driver_8c.html#ab86a216a2ed03e9f270a83c203d5357d',1,'RGBW_LEDs_driver.c']]],
  ['trailing_5fzeros_5f2',['trailing_zeros_2',['../_r_g_b_w___l_e_ds__driver_8c.html#adabbff9450ff082ef07af8f4e9b2de74',1,'RGBW_LEDs_driver.c']]],
  ['transient_5fcfg',['TRANSIENT_CFG',['../accelero_8h.html#a58d61d6441643db61be25c370d249ffd',1,'accelero.h']]],
  ['transient_5fcount',['TRANSIENT_COUNT',['../accelero_8h.html#ae4b6dd317439f9fab815e2b0e4c28b9e',1,'accelero.h']]],
  ['transient_5fsrc',['TRANSIENT_SRC',['../accelero_8h.html#ab4838aeccb48ccb4d21419e1e2ab494f',1,'accelero.h']]],
  ['transient_5fths',['TRANSIENT_THS',['../accelero_8h.html#ac982949b4a93b82dd269971a00034349',1,'accelero.h']]],
  ['trig_5fcfg',['TRIG_CFG',['../accelero_8h.html#adea2a00c32f850ea19382b9d81bed7eb',1,'accelero.h']]],
  ['turn_5fpixel_5foff',['turn_pixel_off',['../_r_g_b_w___l_e_ds__driver_8c.html#aa8ef2732fdea950a4c097e6a8934f372',1,'turn_pixel_off(uint16_t num_pixel):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#aa8ef2732fdea950a4c097e6a8934f372',1,'turn_pixel_off(uint16_t num_pixel):&#160;RGBW_LEDs_driver.c']]],
  ['turn_5fpixel_5fon',['turn_pixel_on',['../_r_g_b_w___l_e_ds__driver_8c.html#af50c07d65fcd9537556e9311ff0be863',1,'turn_pixel_on(uint16_t num_pixel, uint8_t green, uint8_t red, uint8_t blue):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#af50c07d65fcd9537556e9311ff0be863',1,'turn_pixel_on(uint16_t num_pixel, uint8_t green, uint8_t red, uint8_t blue):&#160;RGBW_LEDs_driver.c']]],
  ['turn_5fsymbol',['turn_symbol',['../_r_g_b_w___l_e_ds__driver_8c.html#a3ac6b3a4291d2865fe511a91e667f8de',1,'turn_symbol(uint8_t matrix[], uint8_t green, uint8_t red, uint8_t blue):&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8h.html#a3ac6b3a4291d2865fe511a91e667f8de',1,'turn_symbol(uint8_t matrix[], uint8_t green, uint8_t red, uint8_t blue):&#160;RGBW_LEDs_driver.c']]]
];
