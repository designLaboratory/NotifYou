var searchData=
[
  ['tpm_5fp0_5fperiod',['tpm_p0_period',['../_r_g_b_w___l_e_ds__driver_8c.html#a6cdd70e5d174a5ca9925bfef099cafdb',1,'RGBW_LEDs_driver.c']]],
  ['tpm_5fp1_5fperiod',['tpm_p1_period',['../_r_g_b_w___l_e_ds__driver_8c.html#ab01471d6ed5e172370af0146f2b6df2b',1,'RGBW_LEDs_driver.c']]],
  ['tpm_5fperiod',['tpm_period',['../_r_g_b_w___l_e_ds__driver_8c.html#a4aedc62a6dffa54d596430c03fcbf056',1,'RGBW_LEDs_driver.c']]],
  ['trailing_5fzeros_5f1',['trailing_zeros_1',['../_r_g_b_w___l_e_ds__driver_8c.html#ab86a216a2ed03e9f270a83c203d5357d',1,'RGBW_LEDs_driver.c']]],
  ['trailing_5fzeros_5f2',['trailing_zeros_2',['../_r_g_b_w___l_e_ds__driver_8c.html#adabbff9450ff082ef07af8f4e9b2de74',1,'RGBW_LEDs_driver.c']]]
];
