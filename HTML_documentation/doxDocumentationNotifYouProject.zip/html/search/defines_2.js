var searchData=
[
  ['dma_5flead_5fzeros',['DMA_LEAD_ZEROS',['../_r_g_b_w___l_e_ds__driver_8c.html#aabbfb2541099b70dae0de18173da953c',1,'RGBW_LEDs_driver.c']]],
  ['dma_5ftrail_5fzeros',['DMA_TRAIL_ZEROS',['../_r_g_b_w___l_e_ds__driver_8c.html#aba4d8416327276f5c6afd6b48d45e438',1,'RGBW_LEDs_driver.c']]]
];
