var searchData=
[
  ['notifyou_20project_20documentation',['notifYou project documentation',['../index.html',1,'']]],
  ['notif_5ftab',['Notif_tab',['../_r_g_b_w___l_e_ds__driver_8c.html#ab9925c7bd13ad69f44fb5e536e3845d3',1,'Notif_tab():&#160;RGBW_LEDs_driver.c'],['../uart_8h.html#a5356e90fd9d2fc8796725dd8f05dda91',1,'Notif_tab():&#160;uart.h']]],
  ['notifptr',['notifPtr',['../uart_8h.html#a117f85b1ad2529482434db66040d2896',1,'uart.h']]],
  ['nsec_5fto_5fticks',['NSEC_TO_TICKS',['../_r_g_b_w___l_e_ds__driver_8c.html#a2ca12fad54b07ef7cd2e1d7f9aef54f2',1,'RGBW_LEDs_driver.c']]],
  ['num_5fof_5fleds',['num_of_LEDs',['../_r_g_b_w___l_e_ds__driver_8c.html#a3cb6ae6953326ff3dd2a50a70a1ef865',1,'num_of_LEDs():&#160;RGBW_LEDs_driver.c'],['../_r_g_b_w___l_e_ds__driver_8c.html#a42308849576b2f1ead04e472d38985da',1,'NUM_OF_LEDS():&#160;RGBW_LEDs_driver.c']]],
  ['num_5fof_5fnotifs',['NUM_OF_NOTIFS',['../_r_g_b_w___l_e_ds__driver_8c.html#a7a60675fef4520a6afc43d6ad332177c',1,'RGBW_LEDs_driver.c']]]
];
