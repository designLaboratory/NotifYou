var searchData=
[
  ['ctrl_5freg1',['CTRL_REG1',['../accelero_8h.html#abd83ea49367ca7850ffc9091890aa46b',1,'accelero.h']]],
  ['ctrl_5freg2',['CTRL_REG2',['../accelero_8h.html#afd5ce55297b11bfc3c750a359b80de46',1,'accelero.h']]],
  ['ctrl_5freg3',['CTRL_REG3',['../accelero_8h.html#acdb673970b82f2380da68c9e8d1dc5c6',1,'accelero.h']]],
  ['ctrl_5freg4',['CTRL_REG4',['../accelero_8h.html#a36c532b0a660c101907dcad7ee399fbd',1,'accelero.h']]],
  ['ctrl_5freg5',['CTRL_REG5',['../accelero_8h.html#a97cbbf0a1e80e40544629e925e5a9026',1,'accelero.h']]]
];
