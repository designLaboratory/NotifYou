var searchData=
[
  ['start_5ft0_5fhigh',['start_t0_high',['../_r_g_b_w___l_e_ds__driver_8c.html#a542f0007aa7e2551dccdf4b4d1a4838d',1,'RGBW_LEDs_driver.c']]],
  ['start_5ft1_5flow',['start_t1_low',['../_r_g_b_w___l_e_ds__driver_8c.html#a37c474261656658692e7ea9de3b5214d',1,'RGBW_LEDs_driver.c']]],
  ['sym_5fpart',['Sym_part',['../_r_g_b_w___l_e_ds__driver_8c.html#a2ca4e45237521f3b264757c5e11485eb',1,'RGBW_LEDs_driver.c']]]
];
